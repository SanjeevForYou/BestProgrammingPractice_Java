package lesson10.labs.prob7.sol2;

import static org.junit.Assert.*;

import org.junit.Test;

import lesson10.labs.prob7.Employee;
import lesson10.labs.prob7.Main;

public class Test2 {

	@Test
	public void test() {
		
		Main main = new Main();
		Employee emp =  new Employee("John", "oims", 11000000);
		
		assertEquals(true, main.salaryGreaterThan100000(emp));
		assertEquals(true, main.lastNameAfterM(emp));
	}

}
