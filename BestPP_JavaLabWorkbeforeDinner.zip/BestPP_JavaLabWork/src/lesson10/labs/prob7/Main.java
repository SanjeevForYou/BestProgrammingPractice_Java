package lesson10.labs.prob7;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		Stream<Employee> emps = Arrays.asList(new Employee("Joe", "Davis", 120000),
				          new Employee("John", "Sims", 110000),
				          new Employee("Joe", "Stevens", 200000),
		                  new Employee("Andrew", "Reardon", 80000),
		                  new Employee("Joe", "Cummings", 760000),
		                  new Employee("Steven", "Walters", 135000),
		                  new Employee("Thomas", "Blake", 111000),
		                  new Employee("Alice", "Richards", 101000),
		                  new Employee("Donald", "Trump", 100000)).stream();
		
//		  System.out.println(emps
//				    .filter(e -> (e.getSalary() > 100000))
//				    .filter(e -> (e.getLastName().charAt(0) > 'M'))
//				    .map(e -> fullName(e))
//				    .sorted()
//				    .collect(Collectors.joining(", ")));
			Main m = new Main();	               
		m.printEmps(emps) ;          

	}
	
	public void printEmps(Stream<Employee> lst)
	{Main m = new Main();	
		System.out.println(m.asString(lst));
	}
	
	public String asString(Stream<Employee> lst)
	{
	return lst.filter(e -> e.getSalary()>100000)
			.filter(e -> e.getFirstName().charAt(0)>'M')
			.map(e -> e.firstName +" "+ e.lastName).sorted().collect(Collectors.joining(" ,"));
			
	}
	
	public boolean salaryGreaterThan100000(Employee emp)
	{
		Predicate<Employee> pre = e -> e.getSalary() >100000;
		return pre.test(emp);
	}
	
	public boolean lastNameAfterM(Employee emp)
	{
		Predicate<Employee> pre = e -> e.getLastName().charAt(0)>'M';
		return pre.test(emp);
	}
	
	private static String fullName(Employee e) {
		return e.getFirstName() + " " + e.getLastName();
	}

}
