package lesson10.labs.prob6;

public enum Gender {
	M, F
}
