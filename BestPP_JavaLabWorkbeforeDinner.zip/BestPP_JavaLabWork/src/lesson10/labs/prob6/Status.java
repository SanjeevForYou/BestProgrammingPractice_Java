package lesson10.labs.prob6;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
