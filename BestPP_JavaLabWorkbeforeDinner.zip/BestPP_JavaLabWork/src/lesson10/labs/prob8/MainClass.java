package lesson10.labs.prob8;

public class MainClass {

	public static void main(String[] args) {
		
		Queue q = new Queue();
		q.add("sanjeev");
		q.add("bhusal");
		
		q.remove();
		q.remove();
		
	}

}
